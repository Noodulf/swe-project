const express = require('express');
const router = express.Router();
const Menu = require('../models/menu.js');
const roleCheck = require('../middleware/roleCheck');

// Finalize bill
router.post('/', roleCheck(['manager']), async (req, res) => {
  const { itemName, action, price } = req.body;

  try {
    if (action === 'add') {
      await Menu.create({
        menuItemName: itemName,
        price: price
      });
      return res.status(200).json({ message: 'Item added' });

    } else if (action === 'delete') {
      const deletedCount = await Menu.destroy({
        where: {
          menuItemName: itemName,
          price: price
        }
      });

      if (deletedCount === 0) {
        return res.status(404).json({ message: 'Item not found to delete' });
      }

      return res.status(200).json({ message: 'Item deleted' });

    } else {
      return res.status(400).json({ message: 'Invalid action. Use "add" or "delete".' });
    }
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
