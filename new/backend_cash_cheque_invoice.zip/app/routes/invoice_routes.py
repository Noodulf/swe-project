from flask import Blueprint, request, jsonify
from app.controllers.invoice_controller import (
    get_all_invoices,
    get_invoice_by_id,
    update_invoice_status,
    create_invoice
)
import traceback

invoice_routes = Blueprint('invoice_routes', __name__)

@invoice_routes.route('/', methods=['GET'])
def get_invoices():
    """Get all invoices"""
    return get_all_invoices()

@invoice_routes.route('/<int:invoice_id>', methods=['GET'])
def get_invoice(invoice_id):
    """Get invoice by ID"""
    return get_invoice_by_id(invoice_id)


@invoice_routes.route('/create', methods=['POST'])
def create_new_invoice():
    """Create a new invoice"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['amount', 'supplier_name']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'Missing required field: {field}'
                }), 400
        
        # Create invoice
        invoice, status = create_invoice(
            data['amount'],
            data['supplier_name']
        )
        
        return jsonify({
            'success': True,
            'message': 'Invoice created successfully',
            'data': invoice.to_dict()
        }), 201
        
    except Exception as e:
        print(f"Error creating invoice: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'message': 'Failed to create invoice',
            'error': str(e)
        }), 500

@invoice_routes.route('/<int:invoice_id>/status', methods=['PATCH'])
def update_status(invoice_id):
    """Update invoice status"""
    try:
        data = request.get_json()
        
        if not data or 'status' not in data:
            return jsonify({
                'success': False,
                'message': 'Status is required'
            }), 400
        
        return update_invoice_status(invoice_id, data['status'])
        
    except Exception as e:
        print(f"Error updating invoice status: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to update invoice status',
            'error': str(e)
        }), 500