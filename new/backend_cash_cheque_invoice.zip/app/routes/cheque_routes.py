from flask import Blueprint, request, jsonify
from app.controllers.cheque_controller import (
    get_all_cheques, 
    get_cheque_by_id, 
    get_cheques_by_purchase_order,
    update_cheque_status,
    generate_cheque
)

cheque_bp = Blueprint('cheque', __name__)

@cheque_bp.route('/', methods=['GET'])
def get_cheques():
    """
    Get all cheques
    
    FRONTEND INTEGRATION POINT:
    
    - Use this endpoint to display a list of all generated cheques 
    - Frontend should call this endpoint when loading the cheques management page
    - Display cheque number, amount, issue date, and status in a table format
    """
    return get_all_cheques()

@cheque_bp.route('/<int:cheque_id>', methods=['GET'])
def get_cheque(cheque_id):
    """
    Get a single cheque by ID
    
    FRONTEND INTEGRATION POINT:
    
    - Use this endpoint to display detailed information about a specific cheque
    - Frontend should call this endpoint when a user clicks on a specific cheque in the list
    - Show all cheque details including associated purchase order information
    """
    return get_cheque_by_id(cheque_id)

@cheque_bp.route('/purchase-order/<int:purchase_order_id>', methods=['GET'])
def get_purchase_order_cheques(purchase_order_id):
    """
    Get cheques for a purchase order
    
    FRONTEND INTEGRATION POINT:
    
    - Use this endpoint to display all cheques associated with a specific purchase order
    - Frontend should call this endpoint when viewing purchase order details
    - Include this information in the purchase order details view
    """
    return get_cheques_by_purchase_order(purchase_order_id)

@cheque_bp.route('/<int:cheque_id>/status', methods=['PUT'])
def update_status(cheque_id):
    """
    Update cheque status
    
    FRONTEND INTEGRATION POINT:
    
    - Use this endpoint when a user wants to mark a cheque as cashed or cancelled
    - Frontend should provide a dropdown or buttons to change cheque status
    - Display confirmation message after status is successfully updated
    - If cancelling a cheque, inform the user that the amount will be returned to cash balance
    
    """
    data = request.get_json()
    status = data.get('status')
    
    return update_cheque_status(cheque_id, status)

@cheque_bp.route('/generate', methods=['POST'])
def create_cheque():
    """
    Generate a new cheque
    
    FRONTEND INTEGRATION POINT:
    
    - Use this endpoint to create a new cheque for a purchase order or invoice
    - Frontend should call this endpoint from purchase order or invoice details page
    - Provide form fields for amount and either purchase_order_id or invoice_id
    - Display the generated cheque details after successful creation
    - Update the financial dashboard to reflect the new cheque
    """
    data = request.get_json()
    purchase_order_id = data.get('purchase_order_id')
    amount = data.get('amount')
    invoice_id = data.get('invoice_id', None)
    
    return generate_cheque(purchase_order_id, amount, invoice_id)