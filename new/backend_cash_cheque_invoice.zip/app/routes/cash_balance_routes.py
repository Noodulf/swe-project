from flask import Blueprint, request, jsonify
from app.controllers.cash_balance_controller import get_current_balance

cash_balance_bp = Blueprint('cash_balance', __name__)

@cash_balance_bp.route('/', methods=['GET'])
def get_balance():
    """
    Get the current cash balance
    
    FRONTEND INTEGRATION POINT:
    
    - Use this endpoint to display the current cash balance in the UI
    - Frontend should call this endpoint when loading the purchase order approval page
    - This can be used to show users the available balance before they attempt to approve orders
    """
    return get_current_balance()