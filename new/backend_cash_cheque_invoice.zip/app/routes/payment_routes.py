from flask import Blueprint, request, jsonify
from app.controllers.payment_controller import (
    process_invoice_payment,
    process_pending_invoices,
    get_monthly_financial_report
)
import traceback

payment_bp = Blueprint('payment', __name__)

@payment_bp.route('/process-invoice/<int:invoice_id>', methods=['POST'])
def pay_invoice(invoice_id):
    """Process payment for a specific invoice"""
    return process_invoice_payment(invoice_id)

@payment_bp.route('/process-pending', methods=['POST'])
def process_all_pending():
    """Process all pending invoices automatically"""
    return process_pending_invoices()

@payment_bp.route('/monthly-report', methods=['GET'])
def get_monthly_report():
    """Get monthly financial report"""
    try:
        # Get year and month from query parameters
        year = request.args.get('year')
        month = request.args.get('month')
        
        if not year or not month:
            return jsonify({
                'success': False,
                'message': 'Year and month parameters are required'
            }), 400
        
        try:
            year = int(year)
            month = int(month)
        except ValueError:
            return jsonify({
                'success': False,
                'message': 'Year and month must be valid integers'
            }), 400
        
        return get_monthly_financial_report(year, month)
        
    except Exception as e:
        print(f"Error fetching monthly report: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'message': 'Failed to fetch monthly report',
            'error': str(e)
        }), 500