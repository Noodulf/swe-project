from app import db
from app.models.cheque import Cheque
from app.models.invoice import Invoice
from datetime import datetime, timezone
from flask import jsonify
import time
import random
from app.controllers.cash_balance_controller import update_balance

def generate_cheque_number():
    #Generates a unique cheque number
    prefix = 'CHQ'
    timestamp = str(int(time.time()))[-8:]
    random_num = str(random.randint(0, 999)).zfill(3)
    return f"{prefix}-{timestamp}-{random_num}"

def generate_cheque(purchase_order_id, amount, invoice_id=None):
    # Create a new cheque for a purchase order or invoice
    try:
        # First check if we have an invoice ID
        if invoice_id:
            invoice = Invoice.query.get(invoice_id)
            if not invoice:
                raise ValueError(f"Invoice with ID {invoice_id} not found")
            
            # Use the invoice's purchase order ID
            purchase_order_id = invoice.purchase_order_id
            
            # Check if a cheque already exists for this invoice
            existing_cheque = Cheque.query.filter_by(purchase_order_id=purchase_order_id).first()
            if existing_cheque:
                return existing_cheque
        else:
            # Check if a cheque already exists for this purchase order
            existing_cheque = Cheque.query.filter_by(purchase_order_id=purchase_order_id).first()
            if existing_cheque:
                return existing_cheque
        
        # Generate unique cheque no.
        cheque_number = generate_cheque_number()
        
        # Create new cheque
        cheque = Cheque(
            purchase_order_id=purchase_order_id,
            amount=amount,
            cheque_number=cheque_number,
            issue_date=datetime.now(timezone.utc),
            status='issued'
        )
        db.session.add(cheque)
        db.session.commit()
        return cheque
    except Exception as e:
        db.session.rollback()
        print(f"Error generating cheque: {str(e)}")
        raise e

def get_all_cheques():
    """Get all cheques"""
    cheques = Cheque.query.order_by(Cheque.issue_date.desc()).all()
    return jsonify({
        'success': True,
        'data': [cheque.to_dict() for cheque in cheques]
    }), 200

def get_cheque_by_id(cheque_id):
    #Get a single cheque by ID
    try:
        cheque = Cheque.query.get(cheque_id)
        #error handling 
        if not cheque:
            return jsonify({
                'success': False,
                'message': 'Cheque not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': cheque.to_dict()
        }), 200
    except Exception as e: #
        print(f"Error fetching cheque {cheque_id}: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to fetch cheque',
            'error': str(e)
        }), 500

def get_cheques_by_purchase_order(purchase_order_id):
    #Get cheques for a purchase order
    try:
        cheques = Cheque.query.filter_by(purchase_order_id=purchase_order_id).order_by(Cheque.issue_date.desc()).all()
        
        return jsonify({
            'success': True,
            'data': [cheque.to_dict() for cheque in cheques]
        }), 200
    except Exception as e:
        print(f"Error fetching cheques for PO {purchase_order_id}: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to fetch cheques for purchase order',
            'error': str(e)
        }), 500

def update_cheque_status(cheque_id, status):
    """Update cheque status"""
    try:
        if status not in ['issued', 'cashed', 'cancelled']:
            return jsonify({
                'success': False,
                'message': 'Valid status is required (issued, cashed, cancelled)'
            }), 400
        
        cheque = Cheque.query.get(cheque_id)
        
        if not cheque:
            return jsonify({
                'success': False,
                'message': 'Cheque not found'
            }), 404
        
        # If cancelling a cheque, return the money to cash balance
        if status == 'cancelled' and cheque.status != 'cancelled':
            update_balance(cheque.amount)
        
        cheque.status = status
        cheque.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': cheque.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        print(f"Error updating cheque {cheque_id} status: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to update cheque status',
            'error': str(e)
        }), 500