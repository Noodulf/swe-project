from app import db
from app.models.invoice import Invoice
from app.models.cheque import Cheque
from app.controllers.cash_balance_controller import has_enough_balance, update_balance
from app.controllers.cheque_controller import generate_cheque
from flask import jsonify
from datetime import datetime, timezone, timedelta
import traceback

def process_invoice_payment(invoice_id):
    """Process payment for an invoice, generating a cheque if sufficient cash balance is available"""
    try:
        # Find the invoice
        invoice = Invoice.query.get(invoice_id)
        
        if not invoice:
            return jsonify({
                'success': False,
                'message': 'Invoice not found'
            }), 404
            
        # Check if invoice is already paid
        if invoice.status == 'paid':
            return jsonify({
                'success': False,
                'message': 'Invoice is already paid'
            }), 400
            
        # Check if we have enough cash balance
        if not has_enough_balance(invoice.amount):
            return jsonify({
                'success': False,
                'message': 'Insufficient cash balance to process payment'
            }), 400
            
        # Start a transaction
        db_session = db.session
        
        try:
            # Deduct the amount from cash balance
            update_balance(-invoice.amount)
            
            # Generate a cheque for the invoice
            cheque = generate_cheque(None, invoice.amount, invoice_id)
            
            # Update invoice status to paid
            invoice.status = 'paid'
            invoice.updated_at = datetime.now(timezone.utc)
            
            db_session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Payment processed successfully',
                'data': {
                    'invoice': invoice.to_dict(),
                    'cheque': cheque.to_dict()
                }
            }), 200
            
        except Exception as e:
            db_session.rollback()
            raise e
            
    except Exception as e:
        print(f"Error processing invoice payment: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'message': 'Failed to process invoice payment',
            'error': str(e)
        }), 500

def process_pending_invoices():
    """Auto-process all pending invoices, generating cheques for those with sufficient cash balance"""
    try:
        # Get all pending invoices
        pending_invoices = Invoice.query.filter_by(status='pending').order_by(Invoice.issue_date.asc()).all()
        
        if not pending_invoices:
            return jsonify({
                'success': True,
                'message': 'No pending invoices to process',
                'data': []
            }), 200
        
        processed_invoices = []
        insufficient_funds_invoices = []
        
        for invoice in pending_invoices:
            # Check if we have enough cash balance
            if has_enough_balance(invoice.amount):
                # Process the invoice payment
                try:
                    # Deduct from cash balance
                    update_balance(-invoice.amount)
                    
                    # Generate a cheque
                    cheque = generate_cheque(None, invoice.amount, invoice.id)
                    
                    # Update invoice status
                    invoice.status = 'paid'
                    invoice.updated_at = datetime.now(timezone.utc)
                    
                    db.session.commit()
                    
                    # Add to processed list
                    processed_invoices.append({
                        'invoice': invoice.to_dict(),
                        'cheque': cheque.to_dict()
                    })
                    
                except Exception as e:
                    db.session.rollback()
                    print(f"Error processing invoice {invoice.id}: {str(e)}")
            else:
                # Not enough funds
                insufficient_funds_invoices.append(invoice.to_dict())
        
        return jsonify({
            'success': True,
            'message': f'Processed {len(processed_invoices)} invoices, {len(insufficient_funds_invoices)} with insufficient funds',
            'data': {
                'processed': processed_invoices,
                'insufficient_funds': insufficient_funds_invoices
            }
        }), 200
        
    except Exception as e:
        print(f"Error processing pending invoices: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'message': 'Failed to process pending invoices',
            'error': str(e)
        }), 500

def get_monthly_financial_report(year, month):
    """Generate monthly financial report for specified year and month"""
    try:
        # Calculate start and end dates for the month
        if month < 1 or month > 12:
            return jsonify({
                'success': False,
                'message': 'Invalid month. Month must be between 1 and 12'
            }), 400
            
        start_date = datetime(year, month, 1, tzinfo=timezone.utc)
        
        # Calculate end date (first day of next month)
        if month == 12:
            end_date = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
        else:
            end_date = datetime(year, month + 1, 1, tzinfo=timezone.utc)
        
        # Get all paid invoices for the month (expenses)
        invoices = Invoice.query.filter(
            Invoice.status == 'paid',
            Invoice.issue_date >= start_date,
            Invoice.issue_date < end_date
        ).all()
        
        # Calculate total expenses
        total_expenses = sum(invoice.amount for invoice in invoices)
        
        # Get all issued cheques for the month
        cheques = Cheque.query.filter(
            Cheque.issue_date >= start_date,
            Cheque.issue_date < end_date
        ).all()
        
        # Get current cash balance
        from app.models.cash_balance import CashBalance
        cash_balance = CashBalance.query.first()
        current_balance = cash_balance.balance if cash_balance else 0
        
        # Format the report
        report = {
            'period': {
                'year': year,
                'month': month,
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat()
            },
            'expenses': {
                'total': total_expenses,
                'invoices': [invoice.to_dict() for invoice in invoices]
            },
            'cheques': {
                'total': sum(cheque.amount for cheque in cheques),
                'issued': [cheque.to_dict() for cheque in cheques]
            },
            'cash_balance': {
                'current': current_balance,
                'last_updated': cash_balance.last_updated.isoformat() if cash_balance else None
            }
        }
        
        return jsonify({
            'success': True,
            'data': report
        }), 200
        
    except Exception as e:
        print(f"Error generating monthly report: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'message': 'Failed to generate monthly financial report',
            'error': str(e)
        }), 500