from app import db
from app.models.invoice import Invoice
from flask import jsonify
from datetime import datetime, timezone, timedelta
import time
import random
import traceback

def generate_invoice_number():
    """Generates a unique invoice number"""
    prefix = 'INV'
    timestamp = str(int(time.time()))[-8:]
    random_num = str(random.randint(0, 999)).zfill(3)
    return f"{prefix}-{timestamp}-{random_num}"

def create_invoice(amount, supplier_name):
    """Create a new invoice"""
    try:
        # Generate invoice number
        invoice_number = generate_invoice_number()
        
        # Set due date (30 days from now by default)
        due_date = datetime.now(timezone.utc) + timedelta(days=30)
        
        # Create new invoice
        invoice = Invoice(
            invoice_number=invoice_number,
            amount=amount,
            issue_date=datetime.now(timezone.utc),
            due_date=due_date,
            status='pending',
            supplier_name=supplier_name
        )
        
        db.session.add(invoice)
        db.session.commit()
        
        return invoice, "created"
    except Exception as e:
        db.session.rollback()
        print(f"Error creating invoice: {str(e)}")
        print(traceback.format_exc())
        raise e


def get_all_invoices():
    """Get all invoices"""
    try:
        invoices = Invoice.query.order_by(Invoice.created_at.desc()).all()
        return jsonify({
            'success': True,
            'data': [invoice.to_dict() for invoice in invoices]
        }), 200
    except Exception as e:
        print(f"Error fetching invoices: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to fetch invoices',
            'error': str(e)
        }), 500

def get_invoice_by_id(invoice_id):
    """Get a single invoice by ID"""
    try:
        invoice = Invoice.query.get(invoice_id)
        
        if not invoice:
            return jsonify({
                'success': False,
                'message': 'Invoice not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': invoice.to_dict()
        }), 200
    except Exception as e:
        print(f"Error fetching invoice {invoice_id}: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to fetch invoice',
            'error': str(e)
        }), 500


def update_invoice_status(invoice_id, status):
    """Update invoice status"""
    try:
        if status not in ['pending', 'paid', 'cancelled']:
            return jsonify({
                'success': False,
                'message': 'Valid status is required (pending, paid, cancelled)'
            }), 400
        
        invoice = Invoice.query.get(invoice_id)
        
        if not invoice:
            return jsonify({
                'success': False,
                'message': 'Invoice not found'
            }), 404
        
        invoice.status = status
        invoice.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': invoice.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        print(f"Error updating invoice {invoice_id} status: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to update invoice status',
            'error': str(e)
        }), 500