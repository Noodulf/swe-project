from app import db
from app.models.cash_balance import CashBalance
from datetime import datetime, timezone
from flask import jsonify

def initialize_cash_balance():
    """Initialize cash balance with default 10000"""
    try:
        cash_balance = CashBalance.query.first()
        if not cash_balance:
            cash_balance = CashBalance(
                balance=10000.00, 
                last_updated=datetime.now(timezone.utc),
                created_at=datetime.now(timezone.utc),
                updated_at=datetime.now(timezone.utc)
            )
            db.session.add(cash_balance)
            db.session.commit()
            print("Cash balance initialized successfully")
    except Exception as e:
        db.session.rollback()
        print(f"Error initializing cash balance: {str(e)}")

def get_current_balance():
    #Get the current cash balance
    try:
        cash_balance = CashBalance.query.first()
        if not cash_balance:
            return jsonify({
                'success': False,
                'message': 'Cash balance not found'
            }), 404
        return jsonify({
            'success': True,
            'data': cash_balance.balance
        }), 200
    except Exception as e:
        print(f"Error fetching cash balance: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Failed to fetch cash balance',
            'error': str(e)
        }), 500 

def update_balance(amount):
    """Update the cash balance by adding amount"""
    try:
        cash_balance = CashBalance.query.first()
        
        if not cash_balance:
            cash_balance = CashBalance(
                balance=amount, 
                last_updated=datetime.now(timezone.utc),
                created_at=datetime.now(timezone.utc),
                updated_at=datetime.now(timezone.utc)
            )
            db.session.add(cash_balance)
        else:
            cash_balance.balance += amount
            cash_balance.last_updated = datetime.now(timezone.utc)
            cash_balance.updated_at = datetime.now(timezone.utc)
        
        db.session.commit()
        return cash_balance
    except Exception as e:
        db.session.rollback()
        print(f"Error updating cash balance: {str(e)}")
        raise e

def has_enough_balance(amount):
    #heck if there's enough cash balance for amount
    try:
        cash_balance = CashBalance.query.first()
        
        if not cash_balance:
            return False
        
        return cash_balance.balance >= amount
    except Exception as e:
        print(f"Error checking cash balance: {str(e)}")
        return False