import os

class Config:
    """Base config"""
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # Match existing database configuration from Node.js backend
    SQLALCHEMY_DATABASE_URI = 'mysql://root:sonarani@127.0.0.1/inventory_management'

class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'mysql://root:@127.0.0.1/inventory_management_test'

class ProductionConfig(Config):
    """Production config""" #True for production
    DEBUG = False

config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}