# Payment API Documentation

This document outlines the APIs available for invoice payment processing, automatic cheque generation, and financial reporting in the Restaurant Financial Management System.

## 1. Process Invoice Payment

Processes payment for a specific invoice by generating a cheque if sufficient cash balance is available.

- **URL**: `/api/payments/process-invoice/{invoice_id}`
- **Method**: `POST`
- **URL Parameters**: 
  - `invoice_id`: ID of the invoice to process

### Success Response:
- **Code**: 200
- **Content**:
```json
{
  "success": true,
  "message": "Payment processed successfully",
  "data": {
    "invoice": {
      "id": 1,
      "invoice_number": "INV-12345678-123",
      "amount": 1500.00,
      "issue_date": "2025-04-29T14:30:00Z",
      "due_date": "2025-05-29T14:30:00Z",
      "status": "paid",
      "supplier_name": "Food Supplier Inc.",
      "created_at": "2025-04-29T14:30:00Z",
      "updated_at": "2025-04-29T14:35:00Z"
    },
    "cheque": {
      "id": 1,
      "cheque_number": "CHQ-12345678-123",
      "amount": 1500.00,
      "issue_date": "2025-04-29T14:35:00Z",
      "status": "issued",
      "created_at": "2025-04-29T14:35:00Z",
      "updated_at": "2025-04-29T14:35:00Z"
    }
  }
}
```

### Error Responses:
- **Invoice Not Found**:
  - **Code**: 404
  - **Content**: `{ "success": false, "message": "Invoice not found" }`

- **Already Paid**:
  - **Code**: 400
  - **Content**: `{ "success": false, "message": "Invoice is already paid" }`

- **Insufficient Balance**:
  - **Code**: 400
  - **Content**: `{ "success": false, "message": "Insufficient cash balance to process payment" }`

- **Server Error**:
  - **Code**: 500
  - **Content**: `{ "success": false, "message": "Failed to process invoice payment", "error": "Error message" }`

## 2. Process All Pending Invoices

Automatically processes all pending invoices, generating cheques for those with sufficient cash balance.

- **URL**: `/api/payments/process-pending`
- **Method**: `POST`

### Success Response:
- **Code**: 200
- **Content**:
```json
{
  "success": true,
  "message": "Processed 2 invoices, 1 with insufficient funds",
  "data": {
    "processed": [
      {
        "invoice": { /* invoice details */ },
        "cheque": { /* cheque details */ }
      },
      {
        "invoice": { /* invoice details */ },
        "cheque": { /* cheque details */ }
      }
    ],
    "insufficient_funds": [
      { /* invoice details for invoice that couldn't be processed */ }
    ]
  }
}
```

### Error Responses:
- **No Pending Invoices**:
  - **Code**: 200
  - **Content**: `{ "success": true, "message": "No pending invoices to process", "data": [] }`

- **Server Error**:
  - **Code**: 500
  - **Content**: `{ "success": false, "message": "Failed to process pending invoices", "error": "Error message" }`

## 3. Monthly Financial Report

Generates a financial report for a specified month, including expenses, cheques issued, and current cash balance.

- **URL**: `/api/payments/monthly-report`
- **Method**: `GET`
- **Query Parameters**:
  - `year`: The year (e.g., 2025)
  - `month`: The month (1-12)

### Success Response:
- **Code**: 200
- **Content**:
```json
{
  "success": true,
  "data": {
    "period": {
      "year": 2025,
      "month": 4,
      "start_date": "2025-04-01T00:00:00Z",
      "end_date": "2025-05-01T00:00:00Z"
    },
    "expenses": {
      "total": 5000.00,
      "invoices": [
        { /* invoice details */ },
        { /* invoice details */ }
      ]
    },
    "cheques": {
      "total": 5000.00,
      "issued": [
        { /* cheque details */ },
        { /* cheque details */ }
      ]
    },
    "cash_balance": {
      "current": 15000.00,
      "last_updated": "2025-04-29T14:35:00Z"
    }
  }
}
```

### Error Responses:
- **Missing Parameters**:
  - **Code**: 400
  - **Content**: `{ "success": false, "message": "Year and month parameters are required" }`

- **Invalid Parameters**:
  - **Code**: 400
  - **Content**: `{ "success": false, "message": "Year and month must be valid integers" }`

- **Invalid Month**:
  - **Code**: 400
  - **Content**: `{ "success": false, "message": "Invalid month. Month must be between 1 and 12" }`

- **Server Error**:
  - **Code**: 500
  - **Content**: `{ "success": false, "message": "Failed to generate monthly financial report", "error": "Error message" }`