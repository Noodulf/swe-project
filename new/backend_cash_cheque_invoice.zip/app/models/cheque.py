from app import db
from datetime import datetime, timezone

class Cheque(db.Model):
    __tablename__ = 'cheques'
    
    cheque_id = db.Column(db.Integer, primary_key=True)
    purchase_order_id = db.Column(db.Integer, nullable=False) 
    invoice_id = db.Column(db.Integer, nullable=True)  # Add reference to invoice
    amount = db.Column(db.Float, nullable=False)
    cheque_number = db.Column(db.String(50), nullable=False, unique=True)
    issue_date = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    status = db.Column(db.String(20), nullable=False, default='issued')  
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    def to_dict(self):
        return {
            'cheque_id': self.cheque_id,
            'purchase_order_id': self.purchase_order_id,
            'invoice_id': self.invoice_id,
            'amount': self.amount,
            'cheque_number': self.cheque_number,
            'issue_date': self.issue_date.isoformat() if self.issue_date else None,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }