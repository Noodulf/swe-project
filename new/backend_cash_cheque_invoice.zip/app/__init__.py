from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Initialize SQLAlchemy
db = SQLAlchemy()

def create_app(config_name='default'):
    app = Flask(__name__)
    
    from app.config.config import config
    app.config.from_object(config[config_name])
    
    db.init_app(app)
    CORS(app)  # Enable CORS for all routes
    
    # Create a route to verify the app is running
    @app.route('/')
    def index():
        return {"message": "Restaurant Financial Management System is running"}
    
    # Import and register blueprints
    with app.app_context():
        try:
            # Import models to ensure they're registered with SQLAlchemy
            from app.models.cash_balance import CashBalance
            from app.models.cheque import Cheque
            from app.models.invoice import Invoice
            
            # Create database tables if they don't exist
            logger.info("Creating database tables...")
            db.create_all()
            logger.info("Database tables created successfully")
            
            # Import controllers after models are registered
            from app.controllers.cash_balance_controller import initialize_cash_balance
            # Initialize cash balance with default 10000
            logger.info("Initializing cash balance...")
            initialize_cash_balance()
            logger.info("Cash balance initialized")
            
            # Import and register blueprints
            from app.routes.cash_balance_routes import cash_balance_bp
            from app.routes.cheque_routes import cheque_bp
            from app.routes.invoice_routes import invoice_routes
            from app.routes.payment_routes import payment_bp
            
            app.register_blueprint(cash_balance_bp, url_prefix='/api/cash-balance')
            app.register_blueprint(cheque_bp, url_prefix='/api/cheques')
            app.register_blueprint(invoice_routes, url_prefix='/api/invoices')
            app.register_blueprint(payment_bp, url_prefix='/api/payments')
            logger.info("Blueprints registered successfully")
            
        except Exception as e:
            logger.error(f"Error during app initialization: {str(e)}", exc_info=True)
            
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"success": False, "message": "Endpoint not found"}), 404
        
    @app.errorhandler(500)
    def server_error(error):
        return jsonify({"success": False, "message": "Internal server error"}), 500
    
    return app