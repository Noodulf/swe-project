from app import create_app
import os

# FRONTEND INTEGRATION NOTE:
# This is the main entry point for the Flask backend that handles:
# 1. Cash balance management
# 2. Invoice creation and management
# 3. Cheque generation and management
# 4. Financial reporting


# this backend is running on port 3001
env = os.environ.get('FLASK_ENV', 'development')
app = create_app(env)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 3001)) # Port number for testing
    
    print(f"Starting Flask backend on port {port} in {env} mode...")
    print("Restaurant Financial Management System API server is running.")
    print(f"Access the API at http://localhost:{port}")
    
    # FRONTEND INTEGRATION :
    # Frontend should use the following endpoints:
    
    # Cash Balance Endpoints
    # - GET /api/cash-balance/ - To display current cash balance
    
    # Cheque Endpoints
    # - GET /api/cheques/ - To view all generated cheques
    # - GET /api/cheques/{id} - To view specific cheque details
    # - PUT /api/cheques/{id}/status - To update cheque status
    # - POST /api/cheques/generate - To generate a new cheque
    
    # Invoice Endpoints
    # - GET /api/invoices/ - To get all invoices
    # - GET /api/invoices/{id} - To get a specific invoice
    # - POST /api/invoices/create - To create a new invoice
    # - PATCH /api/invoices/{id}/status - To update invoice status
    
    # Payment Processing Endpoints
    # - POST /api/payments/process-invoice/{id} - To process payment for a specific invoice
    # - POST /api/payments/process-pending - To process all pending invoices
    # - GET /api/payments/monthly-report - To get monthly financial reports
    
    app.run(host='0.0.0.0', port=port, debug=(env == 'development'))