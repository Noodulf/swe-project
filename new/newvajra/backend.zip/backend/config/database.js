const { Sequelize, DataTypes } = require('sequelize');
const config = require('./config.json')[process.env.NODE_ENV || 'development'];

const sequelize = new Sequelize(
  config.database,
  config.username,
  config.password,
  {
    host: config.host,
    dialect: config.dialect,
    logging: config.logging
  }
);

module.exports = { 
  sequelize,
  DataTypes,
  Sequelize
}; 